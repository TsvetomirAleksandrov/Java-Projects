public class Cashier
{
    public String name;
    public static int id;

    Cashier(int id, String name)
    {
        this.id = id;
        this.name = name;
    }
}
